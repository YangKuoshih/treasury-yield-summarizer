
import { XMLParser } from "fast-xml-parser";

const testGoogleRSS = async () => {
    const query = "10 Yr Treasury yield";
    const encodedQuery = encodeURIComponent(query);
    const url = `https://news.google.com/rss/search?q=${encodedQuery}&hl=en-US&gl=US&ceid=US:en`;

    try {
        const res = await fetch(url);
        const text = await res.text();

        console.log("Status:", res.status);
        // console.log("Preview:", text.substring(0, 500)); 

        const parser = new XMLParser();
        const feed = parser.parse(text);

        const items = feed.rss.channel.item.slice(0, 3);

        items.forEach((item, i) => {
            console.log(`\nItem ${i + 1}:`);
            console.log("Title:", item.title);
            console.log("Link:", item.link);
            console.log("Date:", item.pubDate);
        });

    } catch (err) {
        console.error("Error:", err);
    }
};

testGoogleRSS();
