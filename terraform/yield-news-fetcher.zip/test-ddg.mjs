
import { search, SafeSearchType } from "duck-duck-scrape";

const testDDG = async () => {
    try {
        console.log("Testing with safeSearch: SafeSearchType.STRICT");
        // Try importing SafeSearchType or using integers/strings if the enum isn't available
        // Inspecting the exported members of duck-duck-scrape might be useful, 
        // but for now let's try to see if we can import it.
        // Since I'm using "type": "module" in package.json, I can use import in mjs.

        console.log("SafeSearchType:", SafeSearchType);

        const results = await search("test", {
            safeSearch: SafeSearchType.STRICT
        });
        console.log("Success with STRICT!");
    } catch (e) {
        console.error("Failed with STRICT:", e.message);
    }

    try {
        console.log("Testing with safeSearch: 0");
        const results = await search("test", { safeSearch: 0 });
        console.log("Success with 0!");
    } catch (e) {
        console.error("Failed with 0:", e.message);
    }

    try {
        console.log("Testing with safeSearch: 'Strict'");
        const results = await search("test", { safeSearch: 'Strict' });
        console.log("Success with 'Strict'!");
    } catch (e) {
        console.error("Failed with 'Strict':", e.message);
    }
};

testDDG();
